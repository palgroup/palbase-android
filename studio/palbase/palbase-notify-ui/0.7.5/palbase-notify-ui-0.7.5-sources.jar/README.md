studio.palbase:palbase-notify-ui 0.7.5 is distributed compiled; its sources are not published. Docs: https://palbase.studio
