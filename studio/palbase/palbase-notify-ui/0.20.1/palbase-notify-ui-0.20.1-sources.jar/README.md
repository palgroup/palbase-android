studio.palbase:palbase-notify-ui 0.20.1 is distributed compiled; its sources are not published. Docs: https://palbase.studio
