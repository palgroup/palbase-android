studio.palbase:palbase-voice 0.19.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
