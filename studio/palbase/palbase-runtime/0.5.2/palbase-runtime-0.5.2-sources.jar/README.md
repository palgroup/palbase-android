studio.palbase:palbase-runtime 0.5.2 is distributed compiled; its sources are not published. Docs: https://palbase.studio
