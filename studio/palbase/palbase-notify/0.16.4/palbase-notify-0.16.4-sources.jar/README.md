studio.palbase:palbase-notify 0.16.4 is distributed compiled; its sources are not published. Docs: https://palbase.studio
