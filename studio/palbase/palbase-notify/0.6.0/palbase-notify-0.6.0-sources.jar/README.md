studio.palbase:palbase-notify 0.6.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
