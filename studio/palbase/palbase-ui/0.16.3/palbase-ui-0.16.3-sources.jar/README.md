studio.palbase:palbase-ui 0.16.3 is distributed compiled; its sources are not published. Docs: https://palbase.studio
