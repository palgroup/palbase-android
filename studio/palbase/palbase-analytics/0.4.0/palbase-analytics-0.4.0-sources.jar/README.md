studio.palbase:palbase-analytics 0.4.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
