studio.palbase:palbase-palbe 0.16.7 is distributed compiled; its sources are not published. Docs: https://palbase.studio
