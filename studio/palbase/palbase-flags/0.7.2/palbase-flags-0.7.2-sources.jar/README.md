studio.palbase:palbase-flags 0.7.2 is distributed compiled; its sources are not published. Docs: https://palbase.studio
