studio.palbase:palbase-flags 0.9.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
