studio.palbase:palbase-debug 0.7.4 is distributed compiled; its sources are not published. Docs: https://palbase.studio
