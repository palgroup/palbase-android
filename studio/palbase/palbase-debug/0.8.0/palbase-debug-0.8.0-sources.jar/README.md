studio.palbase:palbase-debug 0.8.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
