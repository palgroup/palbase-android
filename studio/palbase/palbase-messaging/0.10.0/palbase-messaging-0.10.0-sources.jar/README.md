studio.palbase:palbase-messaging 0.10.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
