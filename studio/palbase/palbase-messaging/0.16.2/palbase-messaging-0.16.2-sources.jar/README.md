studio.palbase:palbase-messaging 0.16.2 is distributed compiled; its sources are not published. Docs: https://palbase.studio
