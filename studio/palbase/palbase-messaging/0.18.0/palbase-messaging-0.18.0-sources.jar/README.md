studio.palbase:palbase-messaging 0.18.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
