studio.palbase:palbase-storage 0.12.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
