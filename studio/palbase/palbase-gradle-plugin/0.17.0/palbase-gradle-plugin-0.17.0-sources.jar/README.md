studio.palbase:palbase-gradle-plugin 0.17.0 is distributed compiled; its sources are not published. Docs: https://palbase.studio
