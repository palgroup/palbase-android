studio.palbase:palbase-gradle-plugin 0.16.1 is distributed compiled; its sources are not published. Docs: https://palbase.studio
